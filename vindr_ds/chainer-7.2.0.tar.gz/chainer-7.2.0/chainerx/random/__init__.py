from chainerx.random.distributions import normal  # NOQA
from chainerx.random.distributions import uniform  # NOQA
