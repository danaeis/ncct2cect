from chainer.backends import cuda  # NOQA
from chainer.backends import intel64  # NOQA


# TODO(niboshi): Refactor registration of backend modules for functions like
# chainer.get_device().
