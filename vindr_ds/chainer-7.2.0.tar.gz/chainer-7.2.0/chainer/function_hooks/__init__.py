# import classes and functions
from chainer.function_hooks.cuda_profile import CUDAProfileHook  # NOQA
from chainer.function_hooks.cupy_memory_profile import CupyMemoryProfileHook  # NOQA
from chainer.function_hooks.debug_print import PrintHook  # NOQA
from chainer.function_hooks.timer import TimerHook  # NOQA
