# For backward compatibility
from chainer.training.triggers.interval_trigger import IntervalTrigger  # NOQA
from chainer.training.util import _never_fire_trigger  # NOQA
from chainer.training.util import get_trigger  # NOQA
